"""Tipos generados desde cabeceras oficiales para Windows x64."""
from ctypes import *

class _TOCAddress(Union):
    _layout_ = "ms"
    _fields_ = [("lba", c_ulong), ("hmsf", c_ubyte * 4)]

class GUID(Structure):
    _layout_ = "ms"
    pass

class BASS_DEVICEINFO(Structure):
    _layout_ = "ms"
    pass

class BASS_INFO(Structure):
    _layout_ = "ms"
    pass

class BASS_RECORDINFO(Structure):
    _layout_ = "ms"
    pass

class BASS_SAMPLE(Structure):
    _layout_ = "ms"
    pass

class BASS_CHANNELINFO(Structure):
    _layout_ = "ms"
    pass

class BASS_PLUGINFORM(Structure):
    _layout_ = "ms"
    pass

class BASS_PLUGININFO(Structure):
    _layout_ = "ms"
    pass

class BASS_3DVECTOR(Structure):
    _layout_ = "ms"
    pass

class BASS_FILEPROCS(Structure):
    _layout_ = "ms"
    pass

class BASS_FILEOPENPROCS(Structure):
    _layout_ = "ms"
    pass

class TAG_ID3(Structure):
    _layout_ = "ms"
    pass

class TAG_BINARY(Structure):
    _layout_ = "ms"
    pass

class TAG_APE_BINARY(Structure):
    _layout_ = "ms"
    pass

class TAG_BEXT(Structure):
    _layout_ = "ms"
    _pack_ = 1
    pass

class TAG_CART_TIMER(Structure):
    _layout_ = "ms"
    pass

class TAG_CART(Structure):
    _layout_ = "ms"
    pass

class TAG_CUE_POINT(Structure):
    _layout_ = "ms"
    pass

class TAG_CUE(Structure):
    _layout_ = "ms"
    pass

class TAG_SMPL_LOOP(Structure):
    _layout_ = "ms"
    pass

class TAG_SMPL(Structure):
    _layout_ = "ms"
    pass

class TAG_CA_CODEC(Structure):
    _layout_ = "ms"
    pass

class WAVEFORMATEX(Structure):
    _layout_ = "ms"
    _pack_ = 1
    pass

class BASS_DX8_CHORUS(Structure):
    _layout_ = "ms"
    pass

class BASS_DX8_COMPRESSOR(Structure):
    _layout_ = "ms"
    pass

class BASS_DX8_DISTORTION(Structure):
    _layout_ = "ms"
    pass

class BASS_DX8_ECHO(Structure):
    _layout_ = "ms"
    pass

class BASS_DX8_FLANGER(Structure):
    _layout_ = "ms"
    pass

class BASS_DX8_GARGLE(Structure):
    _layout_ = "ms"
    pass

class BASS_DX8_I3DL2REVERB(Structure):
    _layout_ = "ms"
    pass

class BASS_DX8_PARAMEQ(Structure):
    _layout_ = "ms"
    pass

class BASS_DX8_REVERB(Structure):
    _layout_ = "ms"
    pass

class BASS_FX_VOLUME_PARAM(Structure):
    _layout_ = "ms"
    pass

class FFMPEG_TAG(Structure):
    _layout_ = "ms"
    pass

class FFMPEG_TRACK(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_ROTATE(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_ECHO(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_FLANGER(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_VOLUME(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_PEAKEQ(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_REVERB(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_LPF(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_MIX(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_DAMP(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_AUTOWAH(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_ECHO2(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_PHASER(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_ECHO3(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_CHORUS(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_APF(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_COMPRESSOR(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_DISTORTION(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_COMPRESSOR2(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_VOLUME_ENV(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_ENV_NODE(Structure):
    _layout_ = "ms"
    _pack_ = 4
    pass

class BASS_BFX_BQF(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_ECHO4(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_PITCHSHIFT(Structure):
    _layout_ = "ms"
    pass

class BASS_BFX_FREEVERB(Structure):
    _layout_ = "ms"
    pass

class BASS_VST_PARAM_INFO(Structure):
    _layout_ = "ms"
    pass

class BASS_VST_INFO(Structure):
    _layout_ = "ms"
    pass

class BASS_VST_AUDIO_MASTER_PARAM(Structure):
    _layout_ = "ms"
    pass

class BASS_ASIO_DEVICEINFO(Structure):
    _layout_ = "ms"
    pass

class BASS_ASIO_INFO(Structure):
    _layout_ = "ms"
    pass

class BASS_ASIO_CHANNELINFO(Structure):
    _layout_ = "ms"
    pass

class BASS_CD_INFO(Structure):
    _layout_ = "ms"
    pass

class BASS_CD_TOC_TRACK(Structure):
    _layout_ = "ms"
    pass

class BASS_CD_TOC(Structure):
    _layout_ = "ms"
    pass

class TAG_DSD_COMMENT(Structure):
    _layout_ = "ms"
    _pack_ = 1
    pass

class TAG_FLAC_PICTURE(Structure):
    _layout_ = "ms"
    pass

class TAG_FLAC_CUE_TRACK_INDEX(Structure):
    _layout_ = "ms"
    pass

class TAG_FLAC_CUE_TRACK(Structure):
    _layout_ = "ms"
    pass

class TAG_FLAC_CUE(Structure):
    _layout_ = "ms"
    pass

class TAG_FLAC_METADATA(Structure):
    _layout_ = "ms"
    pass

class BASS_MIDI_FONT(Structure):
    _layout_ = "ms"
    pass

class BASS_MIDI_FONTEX(Structure):
    _layout_ = "ms"
    pass

class BASS_MIDI_FONTEX2(Structure):
    _layout_ = "ms"
    pass

class BASS_MIDI_FONTINFO(Structure):
    _layout_ = "ms"
    pass

class BASS_MIDI_MARK(Structure):
    _layout_ = "ms"
    pass

class BASS_MIDI_EVENT(Structure):
    _layout_ = "ms"
    pass

class BASS_MIDI_DEVICEINFO(Structure):
    _layout_ = "ms"
    pass

class BASS_MIXER_NODE(Structure):
    _layout_ = "ms"
    pass

class BASS_OPUS_HEAD(Structure):
    _layout_ = "ms"
    pass

class BASS_WASAPI_DEVICEINFO(Structure):
    _layout_ = "ms"
    pass

class BASS_WASAPI_INFO(Structure):
    _layout_ = "ms"
    pass

class TAG_WEBM_ATTACHMENT(Structure):
    _layout_ = "ms"
    pass

DWORD = c_ulong
WORD = c_ushort
BYTE = c_ubyte
BOOL = c_int
HWND = c_void_p
QWORD = c_ulonglong
HMUSIC = DWORD
HSAMPLE = DWORD
HCHANNEL = DWORD
HSTREAM = DWORD
HRECORD = DWORD
HSYNC = DWORD
HDSP = DWORD
HFX = DWORD
HPLUGIN = DWORD
PWAVEFORMATEX = POINTER(WAVEFORMATEX)
LPWAVEFORMATEX = POINTER(WAVEFORMATEX)
LPCWAVEFORMATEX = POINTER(WAVEFORMATEX)
HENCODE = DWORD
HLOUDNESS = DWORD
HSOUNDFONT = DWORD
HWMENCODE = DWORD
ASIONOTIFYPROC = WINFUNCTYPE(None, DWORD, c_void_p)
ASIOPROC = WINFUNCTYPE(DWORD, BOOL, DWORD, c_void_p, DWORD, c_void_p)
BPMBEATPROC = WINFUNCTYPE(None, DWORD, c_double, c_void_p)
BPMPROC = WINFUNCTYPE(None, DWORD, c_float, c_void_p)
BPMPROGRESSPROC = WINFUNCTYPE(None, DWORD, c_float, c_void_p)
CDDATAPROC = WINFUNCTYPE(None, HSTREAM, c_int, DWORD, c_void_p, DWORD, c_void_p)
CLIENTCONNECTPROC = WINFUNCTYPE(None, HWMENCODE, BOOL, c_char_p, c_void_p)
DEVICENOTIFYPROC = WINFUNCTYPE(None, DWORD)
DOWNLOADPROC = WINFUNCTYPE(None, c_void_p, DWORD, c_void_p)
DSPPROC = WINFUNCTYPE(None, HDSP, DWORD, c_void_p, DWORD, c_void_p)
ENCODECLIENTPROC = WINFUNCTYPE(BOOL, HENCODE, BOOL, c_char_p, c_char_p, c_void_p)
ENCODENOTIFYPROC = WINFUNCTYPE(None, HENCODE, DWORD, c_void_p)
ENCODEPROC = WINFUNCTYPE(None, HENCODE, DWORD, c_void_p, DWORD, c_void_p)
ENCODEPROCEX = WINFUNCTYPE(None, HENCODE, DWORD, c_void_p, DWORD, QWORD, c_void_p)
ENCODERPROC = WINFUNCTYPE(DWORD, HENCODE, DWORD, c_void_p, DWORD, DWORD, c_void_p)
FILECLOSEPROC = WINFUNCTYPE(None, c_void_p)
FILELENPROC = WINFUNCTYPE(QWORD, c_void_p)
FILEOPENPROC = WINFUNCTYPE(c_void_p, c_char_p, DWORD)
FILEREADPROC = WINFUNCTYPE(DWORD, c_void_p, DWORD, c_void_p)
FILESEEKPROC = WINFUNCTYPE(BOOL, QWORD, c_void_p)
IOSNOTIFYPROC = WINFUNCTYPE(None, DWORD)
MIDIFILTERPROC = WINFUNCTYPE(BOOL, HSTREAM, c_int, c_void_p, BOOL, c_void_p)
MIDIINPROC = WINFUNCTYPE(None, DWORD, c_double, c_void_p, DWORD, c_void_p)
MIXERLATENCYPROC = WINFUNCTYPE(DWORD, HSTREAM, c_void_p)
RECORDPROC = WINFUNCTYPE(BOOL, HRECORD, c_void_p, DWORD, c_void_p)
STREAMPROC = WINFUNCTYPE(DWORD, HSTREAM, c_void_p, DWORD, c_void_p)
SYNCPROC = WINFUNCTYPE(None, HSYNC, DWORD, DWORD, c_void_p)
VSTPROC = WINFUNCTYPE(DWORD, DWORD, DWORD, DWORD, DWORD, c_void_p)
WASAPINOTIFYPROC = WINFUNCTYPE(None, DWORD, DWORD, c_void_p)
WASAPIPROC = WINFUNCTYPE(DWORD, c_void_p, DWORD, c_void_p)
WMENCODEPROC = WINFUNCTYPE(None, HWMENCODE, DWORD, c_void_p, DWORD, c_void_p)
BPMPROCESSPROC = BPMPROGRESSPROC
GUID._fields_ = [
    ('Data1', DWORD),
    ('Data2', WORD),
    ('Data3', WORD),
    ('Data4', (BYTE * 8)),
]
BASS_DEVICEINFO._fields_ = [
    ('name', c_char_p),
    ('driver', c_char_p),
    ('flags', DWORD),
]
BASS_INFO._fields_ = [
    ('flags', DWORD),
    ('reserved', (DWORD * 7)),
    ('minbuf', DWORD),
    ('dsver', DWORD),
    ('latency', DWORD),
    ('initflags', DWORD),
    ('speakers', DWORD),
    ('freq', DWORD),
]
BASS_RECORDINFO._fields_ = [
    ('flags', DWORD),
    ('formats', DWORD),
    ('inputs', DWORD),
    ('singlein', BOOL),
    ('freq', DWORD),
]
BASS_SAMPLE._fields_ = [
    ('freq', DWORD),
    ('volume', c_float),
    ('pan', c_float),
    ('flags', DWORD),
    ('length', DWORD),
    ('max', DWORD),
    ('origres', DWORD),
    ('chans', DWORD),
    ('mingap', DWORD),
    ('mode3d', DWORD),
    ('mindist', c_float),
    ('maxdist', c_float),
    ('iangle', DWORD),
    ('oangle', DWORD),
    ('outvol', c_float),
    ('reserved', (DWORD * 2)),
]
BASS_CHANNELINFO._fields_ = [
    ('freq', DWORD),
    ('chans', DWORD),
    ('flags', DWORD),
    ('ctype', DWORD),
    ('origres', DWORD),
    ('plugin', HPLUGIN),
    ('sample', HSAMPLE),
    ('filename', c_char_p),
]
BASS_PLUGINFORM._fields_ = [
    ('ctype', DWORD),
    ('name', c_char_p),
    ('exts', c_char_p),
]
BASS_PLUGININFO._fields_ = [
    ('version', DWORD),
    ('formatc', DWORD),
    ('formats', POINTER(BASS_PLUGINFORM)),
]
BASS_3DVECTOR._fields_ = [
    ('x', c_float),
    ('y', c_float),
    ('z', c_float),
]
BASS_FILEPROCS._fields_ = [
    ('close', FILECLOSEPROC),
    ('length', FILELENPROC),
    ('read', FILEREADPROC),
    ('seek', FILESEEKPROC),
]
BASS_FILEOPENPROCS._fields_ = [
    ('close', FILECLOSEPROC),
    ('length', FILELENPROC),
    ('read', FILEREADPROC),
    ('seek', FILESEEKPROC),
    ('open', FILEOPENPROC),
]
TAG_ID3._fields_ = [
    ('id', (c_char * 3)),
    ('title', (c_char * 30)),
    ('artist', (c_char * 30)),
    ('album', (c_char * 30)),
    ('year', (c_char * 4)),
    ('comment', (c_char * 30)),
    ('genre', BYTE),
]
TAG_BINARY._fields_ = [
    ('data', c_void_p),
    ('length', DWORD),
]
TAG_APE_BINARY._fields_ = [
    ('key', c_char_p),
    ('data', c_void_p),
    ('length', DWORD),
]
TAG_BEXT._fields_ = [
    ('Description', (c_char * 256)),
    ('Originator', (c_char * 32)),
    ('OriginatorReference', (c_char * 32)),
    ('OriginationDate', (c_char * 10)),
    ('OriginationTime', (c_char * 8)),
    ('TimeReference', QWORD),
    ('Version', WORD),
    ('UMID', (BYTE * 64)),
    ('Reserved', (BYTE * 190)),
    ('CodingHistory', (c_char * 0)),
]
TAG_CART_TIMER._fields_ = [
    ('dwUsage', DWORD),
    ('dwValue', DWORD),
]
TAG_CART._fields_ = [
    ('Version', (c_char * 4)),
    ('Title', (c_char * 64)),
    ('Artist', (c_char * 64)),
    ('CutID', (c_char * 64)),
    ('ClientID', (c_char * 64)),
    ('Category', (c_char * 64)),
    ('Classification', (c_char * 64)),
    ('OutCue', (c_char * 64)),
    ('StartDate', (c_char * 10)),
    ('StartTime', (c_char * 8)),
    ('EndDate', (c_char * 10)),
    ('EndTime', (c_char * 8)),
    ('ProducerAppID', (c_char * 64)),
    ('ProducerAppVersion', (c_char * 64)),
    ('UserDef', (c_char * 64)),
    ('dwLevelReference', DWORD),
    ('PostTimer', (TAG_CART_TIMER * 8)),
    ('Reserved', (c_char * 276)),
    ('URL', (c_char * 1024)),
    ('TagText', (c_char * 0)),
]
TAG_CUE_POINT._fields_ = [
    ('dwName', DWORD),
    ('dwPosition', DWORD),
    ('fccChunk', DWORD),
    ('dwChunkStart', DWORD),
    ('dwBlockStart', DWORD),
    ('dwSampleOffset', DWORD),
]
TAG_CUE._fields_ = [
    ('dwCuePoints', DWORD),
    ('CuePoints', (TAG_CUE_POINT * 0)),
]
TAG_SMPL_LOOP._fields_ = [
    ('dwIdentifier', DWORD),
    ('dwType', DWORD),
    ('dwStart', DWORD),
    ('dwEnd', DWORD),
    ('dwFraction', DWORD),
    ('dwPlayCount', DWORD),
]
TAG_SMPL._fields_ = [
    ('dwManufacturer', DWORD),
    ('dwProduct', DWORD),
    ('dwSamplePeriod', DWORD),
    ('dwMIDIUnityNote', DWORD),
    ('dwMIDIPitchFraction', DWORD),
    ('dwSMPTEFormat', DWORD),
    ('dwSMPTEOffset', DWORD),
    ('cSampleLoops', DWORD),
    ('cbSamplerData', DWORD),
    ('SampleLoops', (TAG_SMPL_LOOP * 0)),
]
TAG_CA_CODEC._fields_ = [
    ('ftype', DWORD),
    ('atype', DWORD),
    ('name', c_char_p),
]
WAVEFORMATEX._fields_ = [
    ('wFormatTag', WORD),
    ('nChannels', WORD),
    ('nSamplesPerSec', DWORD),
    ('nAvgBytesPerSec', DWORD),
    ('nBlockAlign', WORD),
    ('wBitsPerSample', WORD),
    ('cbSize', WORD),
]
BASS_DX8_CHORUS._fields_ = [
    ('fWetDryMix', c_float),
    ('fDepth', c_float),
    ('fFeedback', c_float),
    ('fFrequency', c_float),
    ('lWaveform', DWORD),
    ('fDelay', c_float),
    ('lPhase', DWORD),
]
BASS_DX8_COMPRESSOR._fields_ = [
    ('fGain', c_float),
    ('fAttack', c_float),
    ('fRelease', c_float),
    ('fThreshold', c_float),
    ('fRatio', c_float),
    ('fPredelay', c_float),
]
BASS_DX8_DISTORTION._fields_ = [
    ('fGain', c_float),
    ('fEdge', c_float),
    ('fPostEQCenterFrequency', c_float),
    ('fPostEQBandwidth', c_float),
    ('fPreLowpassCutoff', c_float),
]
BASS_DX8_ECHO._fields_ = [
    ('fWetDryMix', c_float),
    ('fFeedback', c_float),
    ('fLeftDelay', c_float),
    ('fRightDelay', c_float),
    ('lPanDelay', BOOL),
]
BASS_DX8_FLANGER._fields_ = [
    ('fWetDryMix', c_float),
    ('fDepth', c_float),
    ('fFeedback', c_float),
    ('fFrequency', c_float),
    ('lWaveform', DWORD),
    ('fDelay', c_float),
    ('lPhase', DWORD),
]
BASS_DX8_GARGLE._fields_ = [
    ('dwRateHz', DWORD),
    ('dwWaveShape', DWORD),
]
BASS_DX8_I3DL2REVERB._fields_ = [
    ('lRoom', c_int),
    ('lRoomHF', c_int),
    ('flRoomRolloffFactor', c_float),
    ('flDecayTime', c_float),
    ('flDecayHFRatio', c_float),
    ('lReflections', c_int),
    ('flReflectionsDelay', c_float),
    ('lReverb', c_int),
    ('flReverbDelay', c_float),
    ('flDiffusion', c_float),
    ('flDensity', c_float),
    ('flHFReference', c_float),
]
BASS_DX8_PARAMEQ._fields_ = [
    ('fCenter', c_float),
    ('fBandwidth', c_float),
    ('fGain', c_float),
]
BASS_DX8_REVERB._fields_ = [
    ('fInGain', c_float),
    ('fReverbMix', c_float),
    ('fReverbTime', c_float),
    ('fHighFreqRTRatio', c_float),
]
BASS_FX_VOLUME_PARAM._fields_ = [
    ('fTarget', c_float),
    ('fCurrent', c_float),
    ('fTime', c_float),
    ('lCurve', DWORD),
]
FFMPEG_TAG._fields_ = [
    ('name', (c_char * 30)),
    ('value', (c_char * 300)),
]
FFMPEG_TRACK._fields_ = [
    ('index', DWORD),
    ('title', (c_char * 30)),
]
BASS_BFX_ROTATE._fields_ = [
    ('fRate', c_float),
    ('lChannel', c_int),
]
BASS_BFX_ECHO._fields_ = [
    ('fLevel', c_float),
    ('lDelay', c_int),
]
BASS_BFX_FLANGER._fields_ = [
    ('fWetDry', c_float),
    ('fSpeed', c_float),
    ('lChannel', c_int),
]
BASS_BFX_VOLUME._fields_ = [
    ('lChannel', c_int),
    ('fVolume', c_float),
]
BASS_BFX_PEAKEQ._fields_ = [
    ('lBand', c_int),
    ('fBandwidth', c_float),
    ('fQ', c_float),
    ('fCenter', c_float),
    ('fGain', c_float),
    ('lChannel', c_int),
]
BASS_BFX_REVERB._fields_ = [
    ('fLevel', c_float),
    ('lDelay', c_int),
]
BASS_BFX_LPF._fields_ = [
    ('fResonance', c_float),
    ('fCutOffFreq', c_float),
    ('lChannel', c_int),
]
BASS_BFX_MIX._fields_ = [
    ('lChannel', POINTER(c_int)),
]
BASS_BFX_DAMP._fields_ = [
    ('fTarget', c_float),
    ('fQuiet', c_float),
    ('fRate', c_float),
    ('fGain', c_float),
    ('fDelay', c_float),
    ('lChannel', c_int),
]
BASS_BFX_AUTOWAH._fields_ = [
    ('fDryMix', c_float),
    ('fWetMix', c_float),
    ('fFeedback', c_float),
    ('fRate', c_float),
    ('fRange', c_float),
    ('fFreq', c_float),
    ('lChannel', c_int),
]
BASS_BFX_ECHO2._fields_ = [
    ('fDryMix', c_float),
    ('fWetMix', c_float),
    ('fFeedback', c_float),
    ('fDelay', c_float),
    ('lChannel', c_int),
]
BASS_BFX_PHASER._fields_ = [
    ('fDryMix', c_float),
    ('fWetMix', c_float),
    ('fFeedback', c_float),
    ('fRate', c_float),
    ('fRange', c_float),
    ('fFreq', c_float),
    ('lChannel', c_int),
]
BASS_BFX_ECHO3._fields_ = [
    ('fDryMix', c_float),
    ('fWetMix', c_float),
    ('fDelay', c_float),
    ('lChannel', c_int),
]
BASS_BFX_CHORUS._fields_ = [
    ('fDryMix', c_float),
    ('fWetMix', c_float),
    ('fFeedback', c_float),
    ('fMinSweep', c_float),
    ('fMaxSweep', c_float),
    ('fRate', c_float),
    ('lChannel', c_int),
]
BASS_BFX_APF._fields_ = [
    ('fGain', c_float),
    ('fDelay', c_float),
    ('lChannel', c_int),
]
BASS_BFX_COMPRESSOR._fields_ = [
    ('fThreshold', c_float),
    ('fAttacktime', c_float),
    ('fReleasetime', c_float),
    ('lChannel', c_int),
]
BASS_BFX_DISTORTION._fields_ = [
    ('fDrive', c_float),
    ('fDryMix', c_float),
    ('fWetMix', c_float),
    ('fFeedback', c_float),
    ('fVolume', c_float),
    ('lChannel', c_int),
]
BASS_BFX_COMPRESSOR2._fields_ = [
    ('fGain', c_float),
    ('fThreshold', c_float),
    ('fRatio', c_float),
    ('fAttack', c_float),
    ('fRelease', c_float),
    ('lChannel', c_int),
]
BASS_BFX_VOLUME_ENV._fields_ = [
    ('lChannel', c_int),
    ('lNodeCount', c_int),
    ('pNodes', POINTER(BASS_BFX_ENV_NODE)),
    ('bFollow', BOOL),
]
BASS_BFX_ENV_NODE._fields_ = [
    ('pos', c_double),
    ('val', c_float),
]
BASS_BFX_BQF._fields_ = [
    ('lFilter', c_int),
    ('fCenter', c_float),
    ('fGain', c_float),
    ('fBandwidth', c_float),
    ('fQ', c_float),
    ('fS', c_float),
    ('lChannel', c_int),
]
BASS_BFX_ECHO4._fields_ = [
    ('fDryMix', c_float),
    ('fWetMix', c_float),
    ('fFeedback', c_float),
    ('fDelay', c_float),
    ('bStereo', BOOL),
    ('lChannel', c_int),
]
BASS_BFX_PITCHSHIFT._fields_ = [
    ('fPitchShift', c_float),
    ('fSemitones', c_float),
    ('lFFTsize', c_long),
    ('lOsamp', c_long),
    ('lChannel', c_int),
]
BASS_BFX_FREEVERB._fields_ = [
    ('fDryMix', c_float),
    ('fWetMix', c_float),
    ('fRoomSize', c_float),
    ('fDamp', c_float),
    ('fWidth', c_float),
    ('lMode', DWORD),
    ('lChannel', c_int),
]
BASS_VST_PARAM_INFO._fields_ = [
    ('name', (c_char * 16)),
    ('unit', (c_char * 16)),
    ('display', (c_char * 16)),
    ('defaultValue', c_float),
]
BASS_VST_INFO._fields_ = [
    ('channelHandle', DWORD),
    ('uniqueID', DWORD),
    ('effectName', (c_char * 80)),
    ('effectVersion', DWORD),
    ('effectVstVersion', DWORD),
    ('hostVstVersion', DWORD),
    ('productName', (c_char * 80)),
    ('vendorName', (c_char * 80)),
    ('vendorVersion', DWORD),
    ('chansIn', DWORD),
    ('chansOut', DWORD),
    ('initialDelay', DWORD),
    ('hasEditor', DWORD),
    ('editorWidth', DWORD),
    ('editorHeight', DWORD),
    ('aeffect', c_void_p),
    ('isInstrument', DWORD),
    ('dspHandle', DWORD),
]
BASS_VST_AUDIO_MASTER_PARAM._fields_ = [
    ('aeffect', c_void_p),
    ('opcode', c_long),
    ('index', c_long),
    ('value', c_longlong),
    ('ptr', c_void_p),
    ('opt', c_float),
    ('doDefault', c_long),
]
BASS_ASIO_DEVICEINFO._fields_ = [
    ('name', c_char_p),
    ('driver', c_char_p),
]
BASS_ASIO_INFO._fields_ = [
    ('name', (c_char * 32)),
    ('version', DWORD),
    ('inputs', DWORD),
    ('outputs', DWORD),
    ('bufmin', DWORD),
    ('bufmax', DWORD),
    ('bufpref', DWORD),
    ('bufgran', c_int),
    ('initflags', DWORD),
]
BASS_ASIO_CHANNELINFO._fields_ = [
    ('group', DWORD),
    ('format', DWORD),
    ('name', (c_char * 32)),
]
BASS_CD_INFO._fields_ = [
    ('vendor', c_char_p),
    ('product', c_char_p),
    ('rev', c_char_p),
    ('letter', c_int),
    ('rwflags', DWORD),
    ('canopen', BOOL),
    ('canlock', BOOL),
    ('maxspeed', DWORD),
    ('cache', DWORD),
    ('cdtext', BOOL),
]
BASS_CD_TOC_TRACK._anonymous_ = ("address",)
BASS_CD_TOC_TRACK._fields_ = [
    ('res1', BYTE),
    ('adrcon', BYTE),
    ('track', BYTE),
    ('res2', BYTE),
    ('address', _TOCAddress),
]
BASS_CD_TOC._fields_ = [
    ('size', WORD),
    ('first', BYTE),
    ('last', BYTE),
    ('tracks', (BASS_CD_TOC_TRACK * 100)),
]
TAG_DSD_COMMENT._fields_ = [
    ('timeStampYear', WORD),
    ('timeStampMonth', BYTE),
    ('timeStampDay', BYTE),
    ('timeStampHour', BYTE),
    ('timeStampMinutes', BYTE),
    ('cmtType', WORD),
    ('cmtRef', WORD),
    ('count', DWORD),
    ('commentText', (c_char * 0)),
]
TAG_FLAC_PICTURE._fields_ = [
    ('apic', DWORD),
    ('mime', c_char_p),
    ('desc', c_char_p),
    ('width', DWORD),
    ('height', DWORD),
    ('depth', DWORD),
    ('colors', DWORD),
    ('length', DWORD),
    ('data', c_void_p),
]
TAG_FLAC_CUE_TRACK_INDEX._fields_ = [
    ('offset', QWORD),
    ('number', DWORD),
]
TAG_FLAC_CUE_TRACK._fields_ = [
    ('offset', QWORD),
    ('number', DWORD),
    ('isrc', c_char_p),
    ('flags', DWORD),
    ('nindexes', DWORD),
    ('indexes', POINTER(TAG_FLAC_CUE_TRACK_INDEX)),
]
TAG_FLAC_CUE._fields_ = [
    ('catalog', c_char_p),
    ('leadin', DWORD),
    ('iscd', BOOL),
    ('ntracks', DWORD),
    ('tracks', POINTER(TAG_FLAC_CUE_TRACK)),
]
TAG_FLAC_METADATA._fields_ = [
    ('id', (c_char * 4)),
    ('length', DWORD),
    ('data', c_void_p),
]
BASS_MIDI_FONT._fields_ = [
    ('font', HSOUNDFONT),
    ('preset', c_int),
    ('bank', c_int),
]
BASS_MIDI_FONTEX._fields_ = [
    ('font', HSOUNDFONT),
    ('spreset', c_int),
    ('sbank', c_int),
    ('dpreset', c_int),
    ('dbank', c_int),
    ('dbanklsb', c_int),
]
BASS_MIDI_FONTEX2._fields_ = [
    ('font', HSOUNDFONT),
    ('spreset', c_int),
    ('sbank', c_int),
    ('dpreset', c_int),
    ('dbank', c_int),
    ('dbanklsb', c_int),
    ('minchan', DWORD),
    ('numchan', DWORD),
]
BASS_MIDI_FONTINFO._fields_ = [
    ('name', c_char_p),
    ('copyright', c_char_p),
    ('comment', c_char_p),
    ('presets', DWORD),
    ('samsize', DWORD),
    ('samload', DWORD),
    ('samtype', DWORD),
]
BASS_MIDI_MARK._fields_ = [
    ('track', DWORD),
    ('pos', DWORD),
    ('text', c_char_p),
]
BASS_MIDI_EVENT._fields_ = [
    ('event', DWORD),
    ('param', DWORD),
    ('chan', DWORD),
    ('tick', DWORD),
    ('pos', DWORD),
]
BASS_MIDI_DEVICEINFO._fields_ = [
    ('name', c_char_p),
    ('id', DWORD),
    ('flags', DWORD),
]
BASS_MIXER_NODE._fields_ = [
    ('pos', QWORD),
    ('value', c_float),
]
BASS_OPUS_HEAD._fields_ = [
    ('version', BYTE),
    ('channels', BYTE),
    ('preskip', WORD),
    ('inputrate', DWORD),
    ('gain', c_short),
    ('mapping', BYTE),
    ('streams', BYTE),
    ('coupled', BYTE),
    ('chanmap', (BYTE * 255)),
]
BASS_WASAPI_DEVICEINFO._fields_ = [
    ('name', c_char_p),
    ('id', c_char_p),
    ('type', DWORD),
    ('flags', DWORD),
    ('minperiod', c_float),
    ('defperiod', c_float),
    ('mixfreq', DWORD),
    ('mixchans', DWORD),
]
BASS_WASAPI_INFO._fields_ = [
    ('initflags', DWORD),
    ('freq', DWORD),
    ('chans', DWORD),
    ('format', DWORD),
    ('buflen', DWORD),
    ('volmax', c_float),
    ('volmin', c_float),
    ('volstep', c_float),
]
TAG_WEBM_ATTACHMENT._fields_ = [
    ('description', c_char_p),
    ('filename', c_char_p),
    ('mediatype', c_char_p),
    ('data', c_void_p),
    ('length', DWORD),
]
