"""Carga y publicación atómica de funciones nativas con ABI declarada."""
from threading import RLock
from ._firmas import FIRMAS
from ..cargador import cargar_bass, cargar_addon


class API:
    def __init__(self, nombre: str):
        self._nombre = nombre
        self._dll = None
        self._lock = RLock()

    def __getattr__(self, nombre: str):
        firmas = FIRMAS.get(self._nombre, {})
        if nombre not in firmas:
            raise AttributeError(f"{self._nombre}: función sin firma oficial: {nombre}")
        with self._lock:
            if self._dll is None:
                dll = cargar_bass() if self._nombre == "bass" else cargar_addon(self._nombre)
                if dll is None:
                    raise OSError(f"{self._nombre}.dll no disponible")
                for funcion, (retorno, argumentos) in firmas.items():
                    try:
                        native = getattr(dll, funcion)
                    except AttributeError:
                        continue  # Versiones antiguas o API exclusiva de otra plataforma.
                    native.restype = retorno
                    native.argtypes = argumentos
                self._dll = dll
            return getattr(self._dll, nombre)

    def __dir__(self):
        return sorted(FIRMAS.get(self._nombre, {}))
