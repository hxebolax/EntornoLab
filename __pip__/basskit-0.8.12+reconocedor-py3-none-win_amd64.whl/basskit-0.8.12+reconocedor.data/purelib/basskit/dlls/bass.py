"""API nativa de bass; firmas del SDK oficial, carga perezosa."""
from ._proxy import API

bass = API('bass')
