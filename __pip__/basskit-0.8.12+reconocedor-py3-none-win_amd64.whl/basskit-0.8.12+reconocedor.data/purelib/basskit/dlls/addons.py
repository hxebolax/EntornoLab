"""API de complementos con firmas verificadas y carga perezosa."""
from ._proxy import API

basscd = API('basscd')
bassloud = API('bassloud')
tags = API('tags')
bassenc_flac = API('bassenc_flac')
bassenc_mp3 = API('bassenc_mp3')
bassenc_ogg = API('bassenc_ogg')
bassenc_opus = API('bassenc_opus')
bassdsd = API('bassdsd')
basshls = API('basshls')
bassflac = API('bassflac')
bassopus = API('bassopus')
basswebm = API('basswebm')
basswv = API('basswv')
bassalac = API('bassalac')
bassape = API('bassape')
bass_aac = API('bass_aac')
bass_ac3 = API('bass_ac3')
bass_mpc = API('bass_mpc')
bass_spx = API('bass_spx')
bass_tta = API('bass_tta')
bass_ofr = API('bass_ofr')
bass_vst = API('bass_vst')
bassasio = API('bassasio')


class _APIAuxiliarPerezosa:
    """Referencia diferida a una API auxiliar (obtener_api) sin importar el catálogo aquí.

    bass_ssl no tiene firmas BASS: es OpenSSL. Antes de 0.7.0 este nombre era
    un proxy BASS vacío y cualquier llamada fallaba con «función sin firma».
    """

    def __init__(self, nombre):
        self._nombre = nombre

    def _api(self):
        from ..catalogo import obtener_api
        return obtener_api(self._nombre)

    def __getattr__(self, atributo):
        return getattr(self._api(), atributo)

    def __dir__(self):
        return dir(self._api())


bass_ssl = _APIAuxiliarPerezosa('bass_ssl')

bass_dts = API("bass_dts")
bass_ffmpeg = API("bass_ffmpeg")
