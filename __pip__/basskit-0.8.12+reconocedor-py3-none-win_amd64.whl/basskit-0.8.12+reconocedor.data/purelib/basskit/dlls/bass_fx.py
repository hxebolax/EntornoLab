"""API nativa de bass_fx; firmas del SDK oficial, carga perezosa."""
from ._proxy import API

bass_fx = API('bass_fx')
