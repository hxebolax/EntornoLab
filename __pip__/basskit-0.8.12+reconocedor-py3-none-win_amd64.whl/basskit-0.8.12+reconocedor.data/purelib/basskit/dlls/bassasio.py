"""API nativa de bassasio; firmas del SDK oficial, carga perezosa."""
from ._proxy import API

bassasio = API('bassasio')
