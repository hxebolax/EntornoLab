"""API nativa de bassmidi; firmas del SDK oficial, carga perezosa."""
from ._proxy import API

bassmidi = API('bassmidi')
