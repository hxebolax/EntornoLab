"""API nativa de bassmix; firmas del SDK oficial, carga perezosa."""
from ._proxy import API

bassmix = API('bassmix')
