"""API nativa de bassenc; firmas del SDK oficial, carga perezosa."""
from ._proxy import API

bassenc = API('bassenc')
