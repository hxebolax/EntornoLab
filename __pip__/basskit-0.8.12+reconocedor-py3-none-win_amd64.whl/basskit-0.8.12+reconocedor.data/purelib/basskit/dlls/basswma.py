"""API nativa de basswma; firmas del SDK oficial, carga perezosa."""
from ._proxy import API

basswma = API('basswma')
