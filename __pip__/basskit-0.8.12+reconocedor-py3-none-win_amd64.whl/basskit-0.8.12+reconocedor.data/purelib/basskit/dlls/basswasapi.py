"""API nativa de basswasapi; firmas del SDK oficial, carga perezosa."""
from ._proxy import API

basswasapi = API('basswasapi')
