"""Vídeo como fondo del escritorio de Windows, con los iconos encima.

El explorador de Windows dibuja el fondo en una ventana ``WorkerW`` que
queda **por detrás** de los iconos. Esa ventana no existe hasta que se le
pide a ``Progman`` que la cree con el mensaje no documentado ``0x052C``;
después basta con reasignar la ventana de vídeo a ella (``SetParent``) para
que la imagen sustituya al fondo sin tapar los iconos ni la barra de tareas.

    from basskit.herramientas import escritorio

    x, y, ancho, alto = escritorio.pantalla_virtual()
    marco = wx.Frame(None, style=wx.NO_BORDER | wx.FRAME_NO_TASKBAR)
    marco.SetSize(x, y, ancho, alto)
    marco.Show()
    with escritorio.FondoEscritorio(marco.GetHandle()):
        ...                      # el vídeo se pinta como fondo del escritorio
    marco.Destroy()              # al salir vuelve el fondo anterior

Advertencias: mientras es fondo, la ventana **no recibe clics ni teclas**
(los iconos están delante), así que los mandos deben quedarse en la ventana
principal o en atajos globales. Con varios monitores la ventana abarca todo
el escritorio virtual. Solo Windows.
"""
import ctypes as ct
import os
from ctypes import wintypes

MENSAJE_CREAR_WORKERW = 0x052C
SMTO_NORMAL = 0x0000
SPI_SETDESKWALLPAPER = 0x0014
SPIF_UPDATEINIFILE = 0x01
SPIF_SENDCHANGE = 0x02
SM_XVIRTUALSCREEN, SM_YVIRTUALSCREEN = 76, 77
SM_CXVIRTUALSCREEN, SM_CYVIRTUALSCREEN = 78, 79


def _user32():
    if os.name != 'nt':
        raise OSError('El fondo de escritorio solo está disponible en Windows')
    user32 = ct.WinDLL('user32', use_last_error=True)
    user32.FindWindowW.restype = wintypes.HWND
    user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.FindWindowExW.restype = wintypes.HWND
    user32.FindWindowExW.argtypes = [wintypes.HWND, wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.SetParent.restype = wintypes.HWND
    user32.SetParent.argtypes = [wintypes.HWND, wintypes.HWND]
    user32.GetParent.restype = wintypes.HWND
    user32.GetParent.argtypes = [wintypes.HWND]
    user32.SendMessageTimeoutW.restype = wintypes.LPARAM
    user32.SendMessageTimeoutW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM,
                                           wintypes.UINT, wintypes.UINT, ct.POINTER(wintypes.DWORD)]
    user32.SystemParametersInfoW.restype = wintypes.BOOL
    user32.SystemParametersInfoW.argtypes = [wintypes.UINT, wintypes.UINT, ct.c_void_p, wintypes.UINT]
    user32.GetSystemMetrics.restype = ct.c_int
    user32.GetSystemMetrics.argtypes = [ct.c_int]
    return user32


def pantalla_virtual() -> tuple:
    """``(x, y, ancho, alto)`` del escritorio virtual completo."""
    user32 = _user32()
    return (user32.GetSystemMetrics(SM_XVIRTUALSCREEN), user32.GetSystemMetrics(SM_YVIRTUALSCREEN),
            user32.GetSystemMetrics(SM_CXVIRTUALSCREEN), user32.GetSystemMetrics(SM_CYVIRTUALSCREEN))


def monitores() -> list[dict]:
    """Rectángulo de cada monitor, para elegir dónde poner la pantalla completa."""
    user32 = _user32()
    resultado = []
    MONITORENUMPROC = ct.WINFUNCTYPE(wintypes.BOOL, wintypes.HANDLE, wintypes.HDC,
                                     ct.POINTER(wintypes.RECT), wintypes.LPARAM)

    def acumular(monitor, _hdc, rect, _dato):
        r = rect.contents
        resultado.append({'handle': int(monitor), 'x': r.left, 'y': r.top,
                          'ancho': r.right - r.left, 'alto': r.bottom - r.top})
        return True

    user32.EnumDisplayMonitors(None, None, MONITORENUMPROC(acumular), 0)
    return resultado


def ventana_fondo() -> int:
    """HWND de la ventana que dibuja el fondo, creándola si hace falta.

    Devuelve la ``WorkerW`` que queda detrás de los iconos. Si el sistema no
    la expone (algunas configuraciones del explorador) devuelve ``Progman``,
    en cuyo caso el vídeo sí tapa los iconos.
    """
    user32 = _user32()
    progman = user32.FindWindowW('Progman', None)
    if not progman:
        raise OSError('No se encontró la ventana Progman del escritorio')
    resultado = wintypes.DWORD()
    # Dos variantes del mensaje: la clásica de Windows 10 crea una WorkerW de
    # nivel superior; la de (0x0D, 1) crea una WorkerW hija de Progman, que es
    # lo que hace Windows 11, donde SHELLDLL_DefView cuelga de Progman.
    user32.SendMessageTimeoutW(progman, MENSAJE_CREAR_WORKERW, 0, 0, SMTO_NORMAL, 1000, ct.byref(resultado))
    user32.SendMessageTimeoutW(progman, MENSAJE_CREAR_WORKERW, 0x0D, 0x01, SMTO_NORMAL, 1000, ct.byref(resultado))

    encontrada = []
    ENUMPROC = ct.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def revisar(hwnd, _dato):
        if user32.FindWindowExW(hwnd, None, 'SHELLDLL_DefView', None):
            siguiente = user32.FindWindowExW(None, hwnd, 'WorkerW', None)
            if siguiente:
                encontrada.append(siguiente)
                return False
        return True

    user32.EnumWindows(ENUMPROC(revisar), 0)
    if encontrada:
        return int(encontrada[0])
    if user32.FindWindowExW(progman, None, 'SHELLDLL_DefView', None):
        hija = user32.FindWindowExW(progman, None, 'WorkerW', None)
        if hija:
            return int(hija)
    # Sin WorkerW disponible solo queda colgar de Progman: ahí el vídeo tapa
    # los iconos (lo indica FondoEscritorio.tapa_los_iconos).
    return int(progman)


def fijar_como_fondo(hwnd: int) -> int:
    """Coloca la ventana ``hwnd`` como fondo del escritorio.

    Devuelve el padre anterior, que hay que pasar a :func:`restaurar_fondo`.
    """
    user32 = _user32()
    anterior = user32.GetParent(wintypes.HWND(hwnd))
    destino = ventana_fondo()
    if not user32.SetParent(wintypes.HWND(hwnd), wintypes.HWND(destino)):
        raise ct.WinError(ct.get_last_error())
    return int(anterior or 0)


def restaurar_fondo(hwnd: int | None = None, padre_anterior: int = 0):
    """Devuelve la ventana a su padre y repinta el fondo de escritorio original.

    Windows conserva la ruta del fondo del usuario: basta con pedirle que lo
    vuelva a aplicar, sin guardar nada por nuestra cuenta.
    """
    user32 = _user32()
    if hwnd:
        user32.SetParent(wintypes.HWND(hwnd), wintypes.HWND(padre_anterior) if padre_anterior else None)
    user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, None, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE)


class FondoEscritorio:
    """Gestor de contexto: la ventana es fondo mientras dure el bloque.

    ``hwnd``: identificador nativo de la ventana (``ventana.GetHandle()`` en
    wxPython). Al salir se devuelve la ventana y se repinta el fondo real.
    """

    def __init__(self, hwnd: int):
        self.hwnd = int(hwnd)
        self.padre_anterior = 0
        self.activo = False
        self.destino = 0

    def activar(self) -> 'FondoEscritorio':
        if not self.activo:
            self.destino = ventana_fondo()
            self.padre_anterior = fijar_como_fondo(self.hwnd)
            self.activo = True
        return self

    def desactivar(self):
        if self.activo:
            restaurar_fondo(self.hwnd, self.padre_anterior)
            self.activo = False

    @property
    def tapa_los_iconos(self) -> bool:
        """True si el sistema no ofreció una WorkerW y el vídeo queda delante."""
        user32 = _user32()
        return bool(self.destino) and self.destino == int(user32.FindWindowW('Progman', None))

    def __enter__(self):
        return self.activar()

    def __exit__(self, *exc):
        self.desactivar()
