"""Diagnóstico de carga, versiones e integridad de los binarios."""
import ctypes
import hashlib
import json
import platform
import struct
import sys
from ..rutas import obtener_directorio_paquete, listar_dlls_disponibles, obtener_directorio_dlls
from ..cargador import cargar_dll, validar_plataforma
from ..tipos import version_a_texto


def verificar_integridad():
    manifest = obtener_directorio_paquete() / "data/native-manifest.json"
    root = obtener_directorio_dlls()
    result = {}
    for entry in json.loads(manifest.read_text(encoding="utf-8")):
        path = root / entry["dll"]
        if not path.is_file():
            result[path.name] = "ausente"
        else:
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            result[path.name] = "correcto" if actual == entry["sha256"] else "modificado"
    return result


def diagnostico_multimedia() -> dict:
    """Conjunto FFmpeg cargado: versión, variante, licencia, directorio y capacidades."""
    try:
        from .. import multimedia as mm
        resumen = mm.resumen()
        resumen["variante"] = mm.variante_ffmpeg()
        return resumen
    except Exception as exc:  # el diagnóstico nunca debe fallar por FFmpeg
        return {"error": f"{type(exc).__name__}: {exc}"}


def diagnostico(multimedia: bool = False):
    """Estado de la instalación. ``multimedia=True`` añade la sección 'ffmpeg'
    (enumera capacidades: tarda unas décimas de segundo)."""
    info = {
        "python_version": platform.python_version(), "plataforma": platform.system(),
        "arquitectura": f"{struct.calcsize('P') * 8} bits", "arquitectura_os": platform.machine(),
        "ruta_paquete": str(obtener_directorio_paquete()), "dlls_encontradas": [],
        "dlls_cargables": [], "dlls_con_error": [], "version_bass": None,
        "versiones": {}, "estado": "pendiente", "mensajes": [],
        "gil_habilitado": sys._is_gil_enabled() if hasattr(sys, "_is_gil_enabled") else True,
    }
    try:
        validar_plataforma()
        dlls = listar_dlls_disponibles()
        info["dlls_encontradas"] = [p.name for p in dlls]
        core = cargar_dll("bass")
        from ..dlls._proxy import API
        from ..dlls._firmas import FIRMAS
        info["version_bass"] = version_a_texto(API("bass").BASS_GetVersion())
        for path in dlls:
            try:
                cargar_dll(path.stem)
                info["dlls_cargables"].append(path.name)
                for name in FIRMAS.get(path.stem, {}):
                    if name.endswith("GetVersion"):
                        raw = getattr(API(path.stem), name)()
                        info["versiones"][path.name] = str(raw) if path.stem == "tags" else version_a_texto(raw)
                        break
            except Exception as exc:
                info["dlls_con_error"].append({"dll": path.name, "error": str(exc)})
        info["estado"] = "parcial" if info["dlls_con_error"] else "correcto"
        info["mensajes"].append(f"{len(info['dlls_cargables'])} DLL cargables")
    except Exception as exc:
        info["estado"] = "error"
        info["mensajes"].append(str(exc))
    if multimedia:
        info["ffmpeg"] = diagnostico_multimedia()
        if "error" in info["ffmpeg"] and info["estado"] == "correcto":
            info["estado"] = "parcial"
    return info


def imprimir_diagnostico() -> None:
	"""Imprime el diagnóstico en formato legible por consola."""
	info = diagnostico()

	print("=" * 60)
	print("  DIAGNÓSTICO DE BASSKIT")
	print("=" * 60)
	print(f"  Python:        {info['python_version']}")
	print(f"  Plataforma:    {info['plataforma']}")
	print(f"  Arquitectura:  {info['arquitectura']}")
	print(f"  Ruta paquete:  {info['ruta_paquete']}")
	print(f"  Versión BASS:  {info['version_bass'] or 'No disponible'}")
	print(f"  Estado:        {info['estado'].upper()}")
	print("-" * 60)
	print(f"  DLL encontradas:  {len(info['dlls_encontradas'])}")
	print(f"  DLL cargables:    {len(info['dlls_cargables'])}")
	print(f"  DLL con error:    {len(info['dlls_con_error'])}")

	if info["dlls_con_error"]:
		print("\n  DLL con errores:")
		for err in info["dlls_con_error"]:
			print(f"    - {err['dll']}: {err['error']}")

	if info["mensajes"]:
		print("\n  Mensajes:")
		for msg in info["mensajes"]:
			print(f"    • {msg}")

	print("=" * 60)


if __name__ == "__main__":
	imprimir_diagnostico()
