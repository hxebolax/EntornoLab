# -*- coding: utf-8 -*-
"""Paquete de herramientas de basskit."""

from .diagnostico import diagnostico, imprimir_diagnostico
from . import escritorio
from .escritorio import FondoEscritorio, pantalla_virtual, monitores

__all__ = ['diagnostico', 'imprimir_diagnostico', 'escritorio', 'FondoEscritorio',
           'pantalla_virtual', 'monitores']
