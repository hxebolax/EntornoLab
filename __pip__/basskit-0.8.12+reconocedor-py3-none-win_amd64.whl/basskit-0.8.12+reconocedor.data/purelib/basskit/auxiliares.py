"""API C de FFmpeg, OpenSSL y OptimFROG con contratos Windows AMD64.

Los esquemas se generan con Clang. Este módulo no necesita Clang en ejecución.
Los punteros de texto/binarios no se convierten automáticamente en cadenas.
"""
import atexit
import ctypes as ct
from copy import deepcopy
from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path
from threading import RLock
from types import SimpleNamespace

# Traza opcional de llamadas reales (no de resoluciones) para la matriz de
# evidencia: BASSKIT_TRAZA_LLAMADAS=ruta.json registra qué funciones se ejecutan.
_TRAZA = os.environ.get('BASSKIT_TRAZA_LLAMADAS')
_LLAMADAS: dict[str, set] = {}


def _volcar_traza():
    ruta = Path(_TRAZA)
    previo = json.loads(ruta.read_text(encoding='utf-8')) if ruta.is_file() else {}
    for modulo, nombres in _LLAMADAS.items():
        previo[modulo] = sorted(set(previo.get(modulo, [])) | nombres)
    ruta.write_text(json.dumps(previo, indent=1, sort_keys=True), encoding='utf-8')


if _TRAZA:
    atexit.register(_volcar_traza)


def _trazar(modulo, nombre, fn):
    def llamada(*args):
        _LLAMADAS.setdefault(modulo, set()).add(nombre)
        return fn(*args)
    llamada.argtypes, llamada.restype, llamada.__name__ = fn.argtypes, fn.restype, nombre
    llamada._nativa = fn  # para ct.cast a punteros de función
    return llamada

MODULOS = {'avcodec-62': 'ffmpeg', 'avformat-62': 'ffmpeg', 'avutil-60': 'ffmpeg',
           'swresample-6': 'ffmpeg', 'avfilter-11': 'ffmpeg', 'swscale-9': 'ffmpeg',
           'avdevice-62': 'ffmpeg', 'bass_ssl': 'openssl', 'OptimFROG': 'optimfrog'}
_PRIMITIVOS = {'void': None, 'pointer': ct.c_void_p, 'bool': ct.c_bool, 'char': ct.c_char,
    'int8': ct.c_int8, 'uint8': ct.c_uint8, 'int16': ct.c_int16, 'uint16': ct.c_uint16,
    'int32': ct.c_int32, 'uint32': ct.c_uint32, 'long': ct.c_long, 'ulong': ct.c_ulong,
    'int64': ct.c_int64, 'uint64': ct.c_uint64, 'float': ct.c_float, 'double': ct.c_double,
    'longdouble': ct.c_longdouble, 'wchar': ct.c_wchar}


@lru_cache(maxsize=None)
def _esquema(grupo):
    return json.loads((Path(__file__).parent / 'data/auxiliares' / (grupo + '.json')).read_text(encoding='utf-8'))


class _Tipos:
    def __init__(self, esquema):
        self.esquema = esquema
        self.records = {n: type(n, (ct.Union if r['union'] else ct.Structure,), {'_layout_': 'ms'})
                        for n, r in esquema['records'].items()}
        self.terminados = set()
        self.callbacks = {}
        for nombre in self.records:
            self._completar(nombre)
        for nombre, descriptor in esquema['aliases'].items():
            setattr(self, nombre, self.resolver(descriptor, callback=True))
        for nombre, tipo in self.records.items():
            if not hasattr(self, nombre):
                setattr(self, nombre, tipo)

    def resolver(self, descriptor, callback=False):
        if isinstance(descriptor, str):
            return _PRIMITIVOS[descriptor]
        kind, value = descriptor[:2]
        if kind == 'record':
            return self.records[value]
        if kind == 'pointer':
            return ct.POINTER(self.resolver(value))
        if kind == 'array':
            return self.resolver(value) * descriptor[2]
        if kind == 'callback':
            if not callback:
                return ct.c_void_p
            if value not in self.callbacks:
                definition = self.esquema['callbacks'][value]
                if definition['variadica']:
                    # ctypes cannot implement C callbacks with variadic tails.
                    # Native function pointer adapters may still be passed.
                    return ct.c_void_p
                ret = definition['retorno']
                native_ret = ct.c_void_p if isinstance(ret, list) and ret[0] in ('pointer', 'callback') else self.resolver(ret)
                self.callbacks[value] = ct.CFUNCTYPE(native_ret,
                    *(self.resolver(arg) for arg in definition['argumentos']))
            return self.callbacks[value]
        raise ValueError(descriptor)

    def __dir__(self):
        return sorted(set(self.esquema['aliases']) | set(self.records))

    def _completar(self, nombre):
        if nombre in self.terminados:
            return
        row = self.esquema['records'][nombre]
        if row['size'] < 0:
            self.terminados.add(nombre)
            return  # Opaque: obtain through its library allocator.
        def dependencias(desc):
            if isinstance(desc, list) and desc[0] == 'record':
                self._completar(desc[1])
            elif isinstance(desc, list) and desc[0] == 'array':
                dependencias(desc[1])
        for field in row['campos']:
            dependencias(field['tipo'])
        fields = [(f['nombre'] or f'_anon_{i}', self.resolver(f['tipo'])) +
                  ((f['bits'],) if f['bits'] is not None else ()) for i, f in enumerate(row['campos'])]
        def coincide(cls):
            if ct.sizeof(cls) != row['size'] or ct.alignment(cls) != row['align']:
                return False
            for (name, *_), field in zip(fields, row['campos']):
                descriptor = getattr(cls, name)
                offset = descriptor.offset * 8
                if field['bits'] is not None:
                    offset += descriptor.size & 0xffff
                if offset != field['offset_bits']:
                    return False
            return True
        base = ct.Union if row['union'] else ct.Structure
        for pack in (None, 1, 2, 4, 8, 16):
            attrs = {'_layout_': 'ms'}
            anonymous = tuple(f['nombre'] for f in row['campos'] if f.get('anonimo'))
            if anonymous:
                attrs['_anonymous_'] = anonymous
            if pack is not None:
                attrs['_pack_'] = pack
            candidate = type('_Verificar', (base,), dict(attrs, _fields_=fields))
            if coincide(candidate):
                cls = self.records[nombre]
                if anonymous:
                    cls._anonymous_ = anonymous
                if pack is not None:
                    cls._pack_ = pack
                cls._fields_ = fields
                self.terminados.add(nombre)
                return
        raise RuntimeError(f'ABI auxiliar incompatible: {nombre}; SDK size={row["size"]}, align={row["align"]}')


_TIPOS_CACHE = {}
_TIPOS_LOCK = RLock()


def _tipos(grupo):
    with _TIPOS_LOCK:
        if grupo not in _TIPOS_CACHE:
            _TIPOS_CACHE[grupo] = _Tipos(_esquema(grupo))
        return _TIPOS_CACHE[grupo]


MODULOS_FFMPEG = tuple(m for m, g in MODULOS.items() if g == 'ffmpeg')
_registros_directorio = {}


def directorio_grupo(grupo: str) -> Path:
    """Directorio de las DLL de un grupo.

    FFmpeg puede venir de ``BASSKIT_FFMPEG_PATH`` (por ejemplo la variante
    LGPL de la misma versión, véase docs/multimedia/instalacion.md). Debe
    fijarse antes de la primera carga de FFmpeg o de bass_ffmpeg.
    """
    import os
    from .rutas import registrar_directorio_dlls
    base = registrar_directorio_dlls()
    if base is None:
        raise OSError('No se encuentra el directorio de DLL')
    propia = os.environ.get('BASSKIT_FFMPEG_PATH') if grupo == 'ffmpeg' else None
    if not propia:
        return base
    directorio = Path(propia).expanduser().resolve()
    if not directorio.is_dir():
        raise OSError(f'BASSKIT_FFMPEG_PATH no es un directorio: {directorio}')
    with _TIPOS_LOCK:
        if directorio not in _registros_directorio:
            _registros_directorio[directorio] = os.add_dll_directory(str(directorio))
    return directorio


def conjunto_ffmpeg_cargado() -> dict:
    """Ruta real de cada DLL FFmpeg ya cargada en el proceso (GetModuleFileNameW)."""
    kernel32 = ct.WinDLL('kernel32', use_last_error=True)
    kernel32.GetModuleHandleW.restype = ct.c_void_p
    kernel32.GetModuleHandleW.argtypes = [ct.c_wchar_p]
    kernel32.GetModuleFileNameW.argtypes = [ct.c_void_p, ct.c_wchar_p, ct.c_uint32]
    resultado = {}
    for nombre in MODULOS_FFMPEG:
        modulo = kernel32.GetModuleHandleW(nombre + '.dll')
        if modulo:
            buffer = ct.create_unicode_buffer(1024)
            kernel32.GetModuleFileNameW(modulo, buffer, 1024)
            resultado[nombre] = Path(buffer.value)
    return resultado


def verificar_conjunto_ffmpeg():
    """Rechaza un proceso con DLL FFmpeg de directorios distintos (mezcla de compilaciones)."""
    cargadas = conjunto_ffmpeg_cargado()
    directorios = {str(p.parent).lower() for p in cargadas.values()}
    if len(directorios) > 1:
        raise RuntimeError('Mezcla de conjuntos FFmpeg en el proceso: ' +
                           ', '.join(f'{n}={p}' for n, p in cargadas.items()) +
                           '. Fije BASSKIT_FFMPEG_PATH antes de cargar FFmpeg o bass_ffmpeg y reinicie el proceso.')


def precargar_ffmpeg():
    """Carga avutil, swresample, avcodec y avformat del directorio elegido.

    Se llama antes de bass_ffmpeg: Windows reutiliza por nombre un módulo ya
    cargado, así el plugin usa el mismo conjunto que basskit.multimedia.
    """
    from .catalogo import obtener_api
    for nombre in ('avutil-60', 'swresample-6', 'avcodec-62', 'avformat-62'):
        obtener_api(nombre)._cargar()


class APIAuxiliar:
    """Funciones públicas del binario auditado. Inicialización perezosa.

    api.tipos expone estructuras/typedefs; api.constantes los valores del SDK.
    Mantenga vivos callbacks y buffers mientras la biblioteca los utilice.
    """
    def __init__(self, nombre):
        self._nombre = nombre
        self._grupo = MODULOS[nombre]
        self._schema = _esquema(self._grupo)
        self._dll = None
        self._variante = self._ruta = None
        self._lock = RLock()

    @property
    def tipos(self):
        return _tipos(self._grupo)

    @property
    def constantes(self):
        return SimpleNamespace(**self._schema['constantes'])

    def describir(self, nombre):
        """Contrato C, parámetros, comentario, cabecera y línea de una función."""
        return deepcopy(self._schema['funciones'][self._nombre][nombre])

    def crear_callback(self, funcion, argumento, callback):
        """Construye el callback de un argumento (índice desde 0 o nombre C).

        Conserve el objeto devuelto hasta desregistrarlo. Debe capturar sus
        excepciones y respetar el formato/tiempo de vida de los buffers.
        """
        args = self._schema['funciones'][self._nombre][funcion]['argumentos']
        if isinstance(argumento, str):
            definition = next(a for a in args if a['nombre'] == argumento)
        else:
            definition = args[argumento]
        return self._crear_callback(definition['tipo'], callback)

    def crear_callback_campo(self, estructura, campo, callback):
        """Callback para un campo de estructura; asigne cast(ref, c_void_p)."""
        descriptor = self._schema['aliases'].get(estructura, ['record', estructura])
        if not isinstance(descriptor, list) or descriptor[0] != 'record':
            raise ValueError('Se requiere una estructura del SDK')
        fields = self._schema['records'][descriptor[1]]['campos']
        definition = next(f for f in fields if f['nombre'] == campo)
        return self._crear_callback(definition['tipo'], callback)

    def _crear_callback(self, desc, callback):
        if not isinstance(desc, list) or desc[0] != 'callback':
            raise ValueError('El argumento no es un callback del SDK')
        contract = self._schema['callbacks'][desc[1]]
        if contract['variadica'] or (isinstance(contract['retorno'], list) and contract['retorno'][0] == 'record'):
            raise ValueError('Este callback requiere un adaptador C nativo (varargs o retorno de struct por valor)')
        return self.tipos.resolver(desc, callback=True)(callback)

    @property
    def variante(self) -> str | None:
        """'referencia' (binario del paquete) o nombre de la variante aceptada ('lgpl'...)."""
        self._cargar()
        return self._variante

    @property
    def ruta(self) -> Path:
        self._cargar()
        return self._ruta

    def _cargar(self):
        if self._dll is None:
            from .cargador import validar_plataforma
            validar_plataforma()
            directory = directorio_grupo(self._grupo)
            path = directory / (self._nombre + '.dll')
            if not path.is_file():
                raise OSError(f'No existe {path}')
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            aceptados = {self._schema['binarios'][self._nombre]: 'referencia'}
            aceptados.update({h: v for v, h in self._schema.get('binarios_alternativos', {}).get(self._nombre, {}).items()})
            if actual not in aceptados:
                raise RuntimeError(f'{self._nombre}: el binario no coincide con el SDK/ABI auditados ({path})')
            # A distinct CDLL object avoids mutating functions already in use
            # by BASS plugins; the OS shares the loaded module itself.
            self._dll = ct.CDLL(str(path.resolve()), winmode=0x1100)
            self._variante, self._ruta = aceptados[actual], path.resolve()
            if self._grupo == 'ffmpeg':
                verificar_conjunto_ffmpeg()
        return self._dll

    def variable(self, nombre):
        """Acceso explícito a un dato exportado (no una función). No reasignar."""
        definition = self._schema['variables'][self._nombre][nombre]
        with self._lock:
            if definition['tipo'] == ['array', 'char', 0]:
                # Extern const char[] such as SSL_version_str has no declared
                # array length; it is an inline NUL-terminated text object.
                first = ct.c_char.in_dll(self._cargar(), nombre)
                return ct.string_at(ct.addressof(first))
            return self.tipos.resolver(definition['tipo']).in_dll(self._cargar(), nombre)

    def __getattr__(self, nombre):
        functions = self._schema['funciones'][self._nombre]
        if nombre not in functions:
            raise AttributeError(f'{self._nombre}: no es una función pública declarada/exportada: {nombre}')
        with self._lock:
            definition = functions[nombre]
            types = self.tipos
            fn = getattr(self._cargar(), nombre)
            fn.restype = types.resolver(definition['retorno'])
            fn.argtypes = [types.resolver(arg['tipo']) for arg in definition['argumentos']]
            if _TRAZA:
                fn = _trazar(self._nombre, nombre, fn)
            setattr(self, nombre, fn)
            return fn

    def __dir__(self):
        return sorted(self._schema['funciones'][self._nombre])
