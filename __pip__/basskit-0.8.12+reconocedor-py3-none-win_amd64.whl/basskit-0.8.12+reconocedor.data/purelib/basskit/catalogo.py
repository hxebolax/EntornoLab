"""Exploración de las API declaradas sin cargar DLL hasta su primer uso."""
from functools import lru_cache
from .dlls._firmas import FIRMAS
from .dlls._proxy import API
from .auxiliares import APIAuxiliar, MODULOS


def listar_apis() -> tuple[str, ...]:
    """Módulos BASS y API independientes de las seis DLL auxiliares."""
    return tuple(sorted(set(FIRMAS) | set(MODULOS)))


@lru_cache(maxsize=None)
def obtener_api(nombre: str) -> API | APIAuxiliar:
    """Obtiene una API por nombre exacto, por ejemplo 'bassflac'."""
    if nombre in MODULOS:
        return APIAuxiliar(nombre)
    if nombre not in FIRMAS:
        raise ValueError(f"API desconocida: {nombre}; use listar_apis()")
    return API(nombre)


def listar_funciones(nombre: str) -> tuple[str, ...]:
    """Funciones declaradas; no verifica exportaciones de una DLL externa."""
    api = obtener_api(nombre)
    return tuple(dir(api))
