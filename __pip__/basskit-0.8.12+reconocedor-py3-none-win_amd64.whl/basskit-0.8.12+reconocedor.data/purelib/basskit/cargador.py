"""Carga controlada de DLL x64 y sus dependencias."""
import ctypes
import platform
import struct
import sys
import re
from threading import RLock
from .excepciones import ErrorArquitecturaInvalida, ErrorDLLNoEncontrada, ErrorVersionPython
from .rutas import registrar_directorio_dlls

_dlls_cargadas = {}
_lock = RLock()
DLL_PRINCIPAL = "bass"

ADDONS_CONOCIDOS: dict[str, str] = {
	"bass_dts": "bass_dts",
	"bass_ffmpeg": "bass_ffmpeg",
	"bassasio": "bassasio",
	"bass_fx": "bass_fx",
	"bassmix": "bassmix",
	"bassenc": "bassenc",
	"bassenc_flac": "bassenc_flac",
	"bassenc_mp3": "bassenc_mp3",
	"bassenc_ogg": "bassenc_ogg",
	"bassenc_opus": "bassenc_opus",
	"bassmidi": "bassmidi",
	"basswasapi": "basswasapi",
	"bassflac": "bassflac",
	"bassopus": "bassopus",
	"basswma": "basswma",
	"basshls": "basshls",
	"basscd": "basscd",
	"bassdsd": "bassdsd",
	"bassloud": "bassloud",
	"basswebm": "basswebm",
	"basswv": "basswv",
	"bassalac": "bassalac",
	"bassape": "bassape",
	"bass_aac": "bass_aac",
	"bass_ac3": "bass_ac3",
	"bass_mpc": "bass_mpc",
	"bass_spx": "bass_spx",
	"bass_tta": "bass_tta",
	"bass_ofr": "bass_ofr",
	"bass_vst": "bass_vst",
	"bass_ssl": "bass_ssl",
	"tags": "tags",
}

def validar_plataforma():
    if platform.system() != "Windows" or struct.calcsize("P") != 8 or platform.machine().lower() not in ("amd64", "x86_64"):
        raise ErrorArquitecturaInvalida(f"{platform.system()} {platform.machine()} ({struct.calcsize('P') * 8} bits)")
    if sys.version_info < (3, 13):
        raise ErrorVersionPython(platform.python_version())


def cargar_dll(nombre: str, obligatoria: bool = True):
    validar_plataforma()
    if not isinstance(nombre, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", nombre):
        raise ValueError("Use un nombre de DLL sin ruta ni extensión")
    clave = nombre.lower()
    with _lock:
        if clave in _dlls_cargadas:
            return _dlls_cargadas[clave]
        directorio = registrar_directorio_dlls()
        if directorio is None:
            if obligatoria:
                raise ErrorDLLNoEncontrada(nombre, "No se encuentra el directorio de DLL")
            return None
        ruta = directorio / f"{clave}.dll"
        if not ruta.is_file():
            if obligatoria:
                raise ErrorDLLNoEncontrada(ruta.name, str(directorio))
            return None
        # BASS plugins depend on core; sub-encoders also depend on BASSenc.
        if clave not in ("bass", "bassasio", "bass_ssl", "optimfrog"):
            cargar_dll("bass")
        if clave.startswith("bassenc_"):
            cargar_dll("bassenc")
        if clave == "bass_ffmpeg":
            # El plugin debe enlazar el mismo conjunto FFmpeg que basskit.multimedia
            # (BASSKIT_FFMPEG_PATH o el del paquete) y nunca una mezcla.
            from .auxiliares import precargar_ffmpeg
            precargar_ffmpeg()
        if clave in ("avcodec-62", "avformat-62", "avutil-60", "swresample-6", "avfilter-11", "swscale-9", "avdevice-62"):
            from .auxiliares import directorio_grupo, verificar_conjunto_ffmpeg
            ruta = directorio_grupo("ffmpeg") / f"{clave}.dll"
            dll = ctypes.WinDLL(str(ruta.resolve()), winmode=0x1100)
            verificar_conjunto_ffmpeg()
            _dlls_cargadas[clave] = dll
            return dll
        try:
            data = ruta.read_bytes()
            pe = struct.unpack_from("<I", data, 60)[0]
            if data[:2] != b"MZ" or data[pe:pe+4] != b"PE\0\0" or struct.unpack_from("<H", data, pe+4)[0] != 0x8664:
                raise OSError("La DLL no es un binario PE AMD64")
            dll = ctypes.WinDLL(str(ruta.resolve()), winmode=0x1100)
        except (OSError, ValueError, struct.error) as exc:
            if obligatoria:
                raise ErrorDLLNoEncontrada(ruta.name, f"{directorio}: {exc}") from exc
            return None
        _dlls_cargadas[clave] = dll
        return dll


def cargar_bass():
    return cargar_dll("bass")


def cargar_addon(nombre):
    return cargar_dll(ADDONS_CONOCIDOS.get(nombre, nombre), obligatoria=False)


def obtener_dll(nombre):
    with _lock:
        return _dlls_cargadas.get(nombre.lower())


def dlls_cargadas():
    with _lock:
        return dict(_dlls_cargadas)


def descargar_todas():
    """Vacía la caché del cargador; no descarga DLL ni invalida proxies activos.

    Libere antes canales, plugins y dispositivos. Cambiar de versión de DLL
    requiere reiniciar el proceso.
    """
    with _lock:
        _dlls_cargadas.clear()


def cargar_todos_los_addons():
    return {n: dll for n in ADDONS_CONOCIDOS if (dll := cargar_addon(n)) is not None}
