"""Constantes del SDK oficial; archivo generado."""
BASS_CTYPE_STREAM_ALAC = 69120
