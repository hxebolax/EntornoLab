"""Constantes del SDK oficial; archivo generado."""
BASS_CTYPE_STREAM_TTA = 69376
