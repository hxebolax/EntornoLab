# -*- coding: utf-8 -*-
"""Constantes de BASS_FX (bass_fx.dll)."""

# Errores adicionales
BASS_ERROR_FX_NODECODE = 4000
BASS_ERROR_FX_BPMINUSE = 4001

# Flag comun
BASS_FX_FREESOURCE = 0x10000

# Flags de canal DSP
BASS_BFX_CHANALL = -1
BASS_BFX_CHANNONE = 0
BASS_BFX_CHAN1 = 1
BASS_BFX_CHAN2 = 2
BASS_BFX_CHAN3 = 4
BASS_BFX_CHAN4 = 8
BASS_BFX_CHAN5 = 16
BASS_BFX_CHAN6 = 32
BASS_BFX_CHAN7 = 64
BASS_BFX_CHAN8 = 128

# Efectos DSP
(
	BASS_FX_BFX_ROTATE, BASS_FX_BFX_ECHO, BASS_FX_BFX_FLANGER,
	BASS_FX_BFX_VOLUME, BASS_FX_BFX_PEAKEQ, BASS_FX_BFX_REVERB,
	BASS_FX_BFX_LPF, BASS_FX_BFX_MIX, BASS_FX_BFX_DAMP,
	BASS_FX_BFX_AUTOWAH, BASS_FX_BFX_ECHO2, BASS_FX_BFX_PHASER,
	BASS_FX_BFX_ECHO3, BASS_FX_BFX_CHORUS, BASS_FX_BFX_APF,
	BASS_FX_BFX_COMPRESSOR, BASS_FX_BFX_DISTORTION,
	BASS_FX_BFX_COMPRESSOR2, BASS_FX_BFX_VOLUME_ENV, BASS_FX_BFX_BQF,
) = range(0x10000, 0x10000 + 20)

# Filtros BiQuad
(
	BASS_BFX_BQF_LOWPASS, BASS_BFX_BQF_HIGHPASS,
	BASS_BFX_BQF_BANDPASS, BASS_BFX_BQF_BANDPASS_Q,
	BASS_BFX_BQF_NOTCH, BASS_BFX_BQF_ALLPASS,
	BASS_BFX_BQF_PEAKINGEQ, BASS_BFX_BQF_LOWSHELF,
	BASS_BFX_BQF_HIGHSHELF,
) = range(9)

# Atributos Tempo
BASS_ATTRIB_TEMPO = 0x10000
BASS_ATTRIB_TEMPO_PITCH = 0x10001
BASS_ATTRIB_TEMPO_FREQ = 0x10002

# Opciones de Tempo
BASS_ATTRIB_TEMPO_OPTION_USE_AA_FILTER = 0x10010
BASS_ATTRIB_TEMPO_OPTION_AA_FILTER_LENGTH = 0x10011
BASS_ATTRIB_TEMPO_OPTION_USE_QUICKALGO = 0x10012
BASS_ATTRIB_TEMPO_OPTION_SEQUENCE_MS = 0x10013
BASS_ATTRIB_TEMPO_OPTION_SEEKWINDOW_MS = 0x10014
BASS_ATTRIB_TEMPO_OPTION_OVERLAP_MS = 0x10015
BASS_ATTRIB_TEMPO_OPTION_PREVENT_CLICK = 0x10016

# Atributo Reverse
BASS_ATTRIB_REVERSE_DIR = 0x11000

# Direcciones de reproduccion
BASS_FX_RVS_REVERSE = -1
BASS_FX_RVS_FORWARD = 1

# Flags BPM
BASS_FX_BPM_BKGRND = 1
BASS_FX_BPM_MULT2 = 2

# Opciones de traduccion BPM
BASS_FX_BPM_TRAN_X2 = 0
BASS_FX_BPM_TRAN_2FREQ = 1
BASS_FX_BPM_TRAN_FREQ2 = 2
BASS_FX_BPM_TRAN_2PERCENT = 3
BASS_FX_BPM_TRAN_PERCENT2 = 4

from ._sdk_bass_fx import *


def BASS_BFX_CHANNEL_N(n):
    """Máscara del canal 1..32; combine canales con OR."""
    if not isinstance(n, int) or not 1 <= n <= 32:
        raise ValueError("Canal BFX fuera de rango: 1..32")
    return 1 << (n - 1)


def BASS_BFX_Linear2dB(level):
    """Amplitud lineal a dB; cero produce -inf, negativos no son válidos."""
    import math
    if level < 0:
        raise ValueError("La amplitud no puede ser negativa")
    return 20 * math.log10(level) if level else -math.inf


def BASS_BFX_dB2Linear(dB):
    """dB a amplitud lineal, según la macro BASS_FX."""
    return 10 ** (dB / 20)
