"""Constantes del SDK oficial; archivo generado."""
BASS_CTYPE_STREAM_MPC = 68096
