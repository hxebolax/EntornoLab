"""Constantes del SDK oficial; archivo generado."""
BASS_CTYPE_STREAM_OFR = 67072
