"""Constantes del SDK oficial; archivo generado."""
BASS_CTYPE_STREAM_SPX = 68608
