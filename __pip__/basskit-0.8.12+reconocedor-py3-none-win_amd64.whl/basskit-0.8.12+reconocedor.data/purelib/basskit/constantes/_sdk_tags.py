"""Constantes del SDK oficial; archivo generado."""

