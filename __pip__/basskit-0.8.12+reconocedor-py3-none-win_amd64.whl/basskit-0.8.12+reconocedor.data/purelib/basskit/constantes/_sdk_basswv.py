"""Constantes del SDK oficial; archivo generado."""
BASS_CTYPE_STREAM_WV = 66816
