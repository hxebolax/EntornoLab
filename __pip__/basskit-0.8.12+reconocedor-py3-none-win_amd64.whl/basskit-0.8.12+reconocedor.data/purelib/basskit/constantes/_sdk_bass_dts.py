"""Constantes del SDK oficial; archivo generado."""
BASS_CTYPE_STREAM_DTS = 127744
