"""Constantes del SDK oficial; archivo generado."""
BASS_CTYPE_STREAM_APE = 67328
