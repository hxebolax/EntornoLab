# -*- coding: utf-8 -*-
"""
basskit - Audio, vídeo y conversión multimedia para Python en Windows 64 bits.

BASS (Un4seen) con sus addons y FFmpeg 8.1 completo, con API nativa tipada y
capas de alto nivel. Solo Windows 64 bits. Python 3.13+.

Las DLL de BASS y sus add-ons pertenecen a Un4seen Developments Ltd. y el
FFmpeg incluido es GPL v3 o posterior: respete sus licencias.

Uso rápido:
	import basskit
	print(basskit.diagnostico())
	from basskit import multimedia as mm          # vídeo y conversión (FFmpeg)
	from basskit import api                        # las 41 API C por nombre
	from basskit.alto_nivel import Reproductor     # audio con BASS
	from basskit.red import SesionHTTP              # medios con contraseña o 2FA

``basskit.multimedia`` y ``basskit.api`` se importan de forma perezosa al
primer acceso para no cargar DLL al importar el paquete.
"""

from ._version import __version__
from .catalogo import listar_apis, listar_funciones, obtener_api
from .herramientas.diagnostico import diagnostico, imprimir_diagnostico
from .excepciones import (
	BassKitError,
	ErrorDLLNoEncontrada,
	ErrorArquitecturaInvalida,
	ErrorVersionPython,
	ErrorFuncionNoEncontrada,
	ErrorBassNativo,
	ErrorFFmpeg,
	OpcionesNoReconocidas,
	OperacionCancelada,
	CapacidadNoDisponible,
	ErrorArchivoMidi,
)

_SUBPAQUETES_PEREZOSOS = ("multimedia", "api", "alto_nivel", "red", "extensiones")


def __getattr__(nombre):
	if nombre in _SUBPAQUETES_PEREZOSOS:
		import importlib
		return importlib.import_module(f".{nombre}", __name__)
	raise AttributeError(f"module 'basskit' has no attribute '{nombre}'")


__all__ = [
	"listar_apis", "listar_funciones", "obtener_api",
	"__version__",
	"diagnostico",
	"imprimir_diagnostico",
	"BassKitError",
	"ErrorDLLNoEncontrada",
	"ErrorArquitecturaInvalida",
	"ErrorVersionPython",
	"ErrorFuncionNoEncontrada",
	"ErrorBassNativo",
	"ErrorFFmpeg",
	"OpcionesNoReconocidas",
	"OperacionCancelada",
	"CapacidadNoDisponible",
	"ErrorArchivoMidi",
	"multimedia",
	"api",
	"alto_nivel",
	"red",
	"extensiones",
]
