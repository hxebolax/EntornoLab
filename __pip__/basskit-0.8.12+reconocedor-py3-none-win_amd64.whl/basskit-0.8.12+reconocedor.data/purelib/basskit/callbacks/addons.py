"""Definiciones ctypes del SDK oficial para Windows x64."""
from .._tipos_sdk import *
