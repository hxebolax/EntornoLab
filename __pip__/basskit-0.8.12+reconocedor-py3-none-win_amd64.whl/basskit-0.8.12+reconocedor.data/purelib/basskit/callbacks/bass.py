"""Callbacks oficiales y referencias explícitas para API de bajo nivel.

Libere las referencias únicamente después de retirar el callback de BASS.
La capa de alto nivel conserva sus propias referencias.
"""
from threading import RLock
from .._tipos_sdk import *
BASSCALLBACK = WINFUNCTYPE
_referencias_callbacks = []
_lock = RLock()

def mantener_callback(callback):
    with _lock:
        _referencias_callbacks.append(callback)

def liberar_callback(callback):
    """Retira una referencia después de desregistrarla en BASS."""
    with _lock:
        _referencias_callbacks[:] = [c for c in _referencias_callbacks if c is not callback]

def limpiar_callbacks():
    """Solo llamar cuando BASS ya no usa ninguno de los callbacks retenidos."""
    with _lock:
        _referencias_callbacks.clear()
