"""Rutas absolutas y registro persistente de dependencias DLL."""
import os
from pathlib import Path
from threading import RLock

_registros = {}
_lock = RLock()


def obtener_directorio_paquete():
    return Path(__file__).resolve().parent


def obtener_directorio_dlls():
    personalizada = os.environ.get("BASSKIT_DLL_PATH")
    ruta = Path(personalizada).expanduser().resolve() if personalizada else obtener_directorio_paquete() / "data/dlls/x64"
    if not ruta.is_dir():
        raise FileNotFoundError(f"Directorio de DLL inexistente: {ruta}")
    return ruta


def listar_dlls_disponibles():
    try:
        return sorted(obtener_directorio_dlls().glob("*.dll"))
    except FileNotFoundError:
        return []


def registrar_directorio_dlls():
    try:
        directorio = obtener_directorio_dlls()
    except FileNotFoundError:
        return None
    with _lock:
        if hasattr(os, "add_dll_directory") and directorio not in _registros:
            _registros[directorio] = os.add_dll_directory(str(directorio))
    return directorio
