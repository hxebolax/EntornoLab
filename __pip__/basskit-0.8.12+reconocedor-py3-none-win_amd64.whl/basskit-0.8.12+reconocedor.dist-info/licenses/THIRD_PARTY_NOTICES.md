# Licencias y procedencia de binarios

La licencia MIT de `LICENSE` cubre el código Python de basskit. No concede
licencias MIT sobre BASS, sus complementos ni las dependencias FFmpeg.
`LicenseRef-Basskit-Bundle` identifica esta colección con licencias distintas.

- **BASS y BASSASIO**: pertenecen a Un4seen. Sus condiciones distinguen uso no
  comercial y comercial. Véanse los textos originales incluidos en
  `basskit/data/licenses`, [BASS](https://www.un4seen.com/bass.html#license) y
  [BASSASIO](https://www.un4seen.com/bassasio.html). Incorporar estas DLL a una
  rueda no sustituye la licencia necesaria para el producto que las utiliza.
- **Complementos**: se conservan los avisos de sus SDK; no debe asumirse que
  todos tienen las mismas condiciones. BASS_AAC, BASS_FX, OptimFROG y otros
  componentes tienen avisos propios en los archivos descargados.
- **BASS_VST**: repositorio [r10s/BASS_VST](https://github.com/r10s/BASS_VST),
  con licencia LGPL-3.0 en su archivo LICENSE, conservado en el paquete.
- **BASS_DTS 0.5.0**: [repositorio](https://github.com/pudding-fox/BASS_DTS).
  El paquete ManagedBass.Dts declara MIT; el motor libdcadec declara
  LGPL-2.1-o-posterior en sus fuentes. Esas declaraciones no deben confundirse.
- **BASS_FFMPEG 1.0.0**: [repositorio](https://github.com/pudding-fox/BASS_FFMPEG).
  El paquete ManagedBass.Ffmpeg declara MIT. La DLL del plugin distribuida aquí
  contiene modificaciones locales y en 0.6.0 se recompiló contra FFmpeg 8.1.2;
  véase `native/README.md`.
- **FFmpeg 8.1.2** (desde 0.6.0; **desde 0.8.5, compilación de gyan.dev**):
  avcodec-62, avformat-62, avutil-60, avfilter-11, swscale-9, swresample-6,
  avdevice-62, `ffmpeg.exe` y `ffprobe.exe` proceden sin modificar del archivo
  `ffmpeg-8.1.2-full_build-shared.7z`
  (SHA-256 `cba748035c21ce1431d0823c7a3a711f38616f89f87a265dceddf9b7f6749d2d`),
  de [gyan.dev](https://www.gyan.dev/ffmpeg/builds/), compilado desde
  [FFmpeg](https://ffmpeg.org) en el commit `38b88335f9` (el que declara el
  `README.txt` del propio paquete). `avutil_license()` informa **GPL version 3
  or later** (`--enable-gpl --enable-version3`), igual que antes.
  - **Por qué se cambió de compilador**: esta trae `--enable-whisper`, es decir
    el filtro `whisper` de FFmpeg, que es lo que permite transcribir audio a
    subtítulos sin instalar programas aparte. Las compilaciones de BtbN traen
    escrito el script de whisper.cpp, pero su `ffbuild_enabled()` acaba en
    `return -1` y **ninguna** lo activa (comprobadas las de master, n8.1 y n9.0
    del 2026-09-15: todas con `--disable-whisper`). Es la misma versión de
    FFmpeg (8.1.2) y las mismas versiones de biblioteca (avcodec 62.28.102,
    avformat 62.12.102, avutil 60.26.102, avfilter 11.14.102, swscale 9.5.102,
    swresample 6.3.102, avdevice 62.3.102), así que la ABI no cambia; se
    comprobó además que **no falta ninguna** de las funciones que basskit
    declara, y que se pierden solo 32 símbolos JNI de BD-J
    (`Java_org_videolan_*`, `Java_java_awt_*`) que ya estaban clasificados como
    no publicados.
  - La compilación enlaza estáticamente bibliotecas externas como x264, x265,
    libvpx, libaom, SVT-AV1, rav1e, dav1d, libopus, libvorbis, LAME, libass,
    freetype, harfbuzz, fribidi, fontconfig, libxml2, libplacebo, shaderc,
    zimg, soxr, rubberband, SRT, RIST, libssh, libzmq, whisper.cpp, libmysofa,
    libbs2b, libcdio, libgme, libmodplug, OpenAL, frei0r, liblensfun, lcms2,
    libqrencode y otras; **la lista completa es la salida de
    `basskit.multimedia.configuracion()`** y está también en el `README.txt`
    del paquete. Frente a la compilación anterior se pierden `libkvazaar`,
    `libopenh264`, `liblcevc-dec`, `lv2` y `schannel` (siguen x264, x265 y
    gnutls para `https`).
  - **El modelo de whisper no se distribuye**: el filtro necesita un archivo
    GGML que descarga quien lo use (los publica el proyecto whisper.cpp en
    <https://huggingface.co/ggerganov/whisper.cpp>), con su propia licencia.
  - Su licencia completa se incluye en `docs/sdk_auxiliares/ffmpeg/LICENSE.txt`
    (GPLv3) y en `basskit/data/licenses/GPL-3.0.txt`.
  - Las DLL de **BtbN** `win64-gpl-shared` de la misma release siguen
    aceptándose por el cargador como variante `btbn-gpl` (sus SHA-256 están en
    `binarios_alternativos` de `data/auxiliares/ffmpeg.json`), por si alguien
    prefiere no usar whisper.
- **Variante LGPL de FFmpeg 8.1.2** (opcional desde 0.7.0; no se incluye
  en la rueda): `ffmpeg-n8.1.2-50-g1a748fe2cd-win64-lgpl-shared-8.1.zip`
  (SHA-256 `e9712ffbdb03ef71bbab660c75b835bfe698ef6fad0247c76d8d394a39a3db63`),
  misma release y commit. `avutil_license()` informa **LGPL version 3 or
  later**. basskit la acepta si `BASSKIT_FFMPEG_PATH` apunta a su carpeta
  `bin`; quien la redistribuya debe cumplir la LGPLv3 (entre otras cosas,
  permitir sustituir las DLL y ofrecer las fuentes de FFmpeg y de las
  bibliotecas LGPL enlazadas).
- **BASS_SSL**: se entrega la versión del catálogo oficial (OpenSSL 1.1.1w),
  con sus avisos. Esto no afirma que OpenSSL 1.1.1 tenga mantenimiento público
  vigente; no se sustituye por una DLL de OpenSSL de otro ABI.

## Obligaciones GPL de FFmpeg

Distribuir estas DLL o un producto que las incluya exige cumplir la GPLv3:
entre otras cosas, ofrecer el código fuente correspondiente completo de
FFmpeg y de las bibliotecas GPL/LGPL enlazadas, con los scripts de
compilación. El código fuente público de esta compilación está en:

- FFmpeg 8.1.2, commit `38b88335f9`:
  <https://github.com/FFmpeg/FFmpeg/commit/38b88335f9>,
  <https://git.ffmpeg.org/ffmpeg.git>.
- La línea de configuración exacta con la que se compiló está en el
  `README.txt` del paquete y la devuelve `basskit.multimedia.configuracion()`.

**Aviso, para quien vaya a redistribuir**: gyan.dev publica los binarios y el
commit de FFmpeg, pero **no un repositorio con los scripts de compilación**
como sí hace BtbN. La GPLv3 exige ofrecer «los scripts usados para controlar la
compilación», así que quien redistribuya tiene que resolver eso antes: o
conseguir de gyan.dev la receta completa, o recompilar FFmpeg 8.1.2 con
`--enable-whisper` desde una compilación cuya receta sí sea pública (BtbN, con
el `return -1` de su `scripts.d/50-whisper.sh` corregido) y usar esas DLL, que
el cargador acepta con solo apuntar sus SHA-256. Mientras eso no esté resuelto,
esta compilación vale para usarla, no para publicarla.

- Las DLL de BtbN `win64-gpl-shared` de la release `autobuild-2026-08-31-13-27`
  (commit `1a748fe2cd`, SHA-256 del paquete
  `0a41f31caff48e3035b48f09f5d840bd8d1863008240fc43e457f15e589cf5b3`) siguen
  aceptadas como variante y sus scripts sí son públicos:
  <https://github.com/BtbN/FFmpeg-Builds>.

Estos enlaces no constituyen por sí solos una oferta de fuentes conforme a
la GPL para quien redistribuya: el redistribuidor debe conservar y ofrecer
esas fuentes. Si una distribución no puede aceptar la GPL, use la variante
LGPL de la misma compilación, que basskit acepta desde 0.7.0, siguiendo
[instalación multimedia](docs/multimedia/instalacion.md) (sin x264, x265 ni
otros componentes GPL; `bass_ffmpeg` funciona con ambos conjuntos).

La combinación de BASS (licencia propietaria de Un4seen) con componentes
GPL en un mismo producto debe evaluarse según ambas licencias antes de
redistribuir; basskit no ofrece asesoramiento legal.

## Procedencia

La rueda se prepara para uso y revisión local; no se ha publicado en PyPI.
`basskit/data/native-manifest.json` registra URL, SHA-256 del archivo original,
SHA-256 de cada DLL/EXE, versión y, para BASS_FFMPEG, la modificación local.
Los SDK, releases, repositorios y commits consultados se conservan en
`../investigacion`.

## SDK auxiliares

Se incluyen cabeceras y manuales de OpenSSL 1.1.1w con su licencia en
docs/sdk_auxiliares/openssl/LICENSE; cabeceras públicas y manuales HTML de
FFmpeg 8.1.2 con su licencia en docs/sdk_auxiliares/ffmpeg; OptimFROG SDK
1.600 con licencia en docs/sdk_auxiliares/optimfrog/license.html. El
ejecutable ofr.exe no se distribuye. El fixture tests/data/auxiliar.ofr
contiene una onda sintética generada para pruebas. Los medios de las
pruebas multimedia se generan en cada ejecución (tonos y niveles de gris
sintéticos) y no se distribuyen; lo mismo la SoundFont y el MIDI de las
pruebas BASSMIDI. `tests/data/vst_ganancia/ganancia.c` es un plugin VST 2
de prueba escrito para basskit (MIT) sin código del SDK de Steinberg. Las
cabeceras Vulkan, AMF, libvpl, nv-codec-headers (MIT) y OpenCL-Headers de
Khronos (Apache-2.0) utilizadas para generación son dependencias de
desarrollo externas; `tools/sdk_manifest.json` registra su procedencia.
